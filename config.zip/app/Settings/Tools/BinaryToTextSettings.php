<?php

namespace App\Settings\Tools;

class BinaryToTextSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-binary-to-text';
    }
}