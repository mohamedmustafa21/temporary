<?php

namespace App\Settings\Tools;

class UserAgentFinderSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-user-agent-finder';
    }
}