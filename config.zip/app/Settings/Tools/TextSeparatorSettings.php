<?php

namespace App\Settings\Tools;

class TextSeparatorSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-text-separator';
    }
}