<?php

namespace App\Settings\Tools;

class PasswordGeneratorSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-password-generator';
    }
}