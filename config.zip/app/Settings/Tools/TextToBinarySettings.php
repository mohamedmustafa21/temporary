<?php

namespace App\Settings\Tools;

class TextToBinarySettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-text-to-binary';
    }
}