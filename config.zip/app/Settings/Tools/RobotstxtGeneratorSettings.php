<?php

namespace App\Settings\Tools;

class RobotstxtGeneratorSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-robotstxt-generator';
    }
}