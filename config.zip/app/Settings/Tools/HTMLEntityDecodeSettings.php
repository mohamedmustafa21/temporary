<?php

namespace App\Settings\Tools;

class HTMLEntityDecodeSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-html-entity-decode';
    }
}