<?php

namespace App\Settings\Tools;

class SEOTagsGeneratorSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-seo-tags-generator';
    }
}