<?php

namespace App\Settings\Tools;

class CSSMinifierSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-css-minifier';
    }
}