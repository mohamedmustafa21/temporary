<?php

namespace App\Settings\Tools;

class HTMLEntityEncodeSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-html-entity-encode';
    }
}