<?php

namespace App\Settings\Tools;

class WhatsMyIpSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-whats-my-ip';
    }
}