<?php

namespace App\Settings\Tools;

class JSFormatterSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-js-formatter';
    }
}