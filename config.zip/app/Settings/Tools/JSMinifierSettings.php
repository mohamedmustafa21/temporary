<?php

namespace App\Settings\Tools;

class JSMinifierSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-js-minifier';
    }
}