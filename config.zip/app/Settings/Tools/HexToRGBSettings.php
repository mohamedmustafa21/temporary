<?php

namespace App\Settings\Tools;

class HexToRGBSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-hex-to-rgb';
    }
}