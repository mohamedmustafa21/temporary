<?php

namespace App\Settings\Tools;

class WebsiteStatusCheckerSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-website-status-checker';
    }
}