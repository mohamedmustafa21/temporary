<?php

namespace App\Settings\Tools;

class MarkdownToHTMLSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-markdown-to-html';
    }
}