<?php

namespace App\Settings\Tools;

class IPToHostnameSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-ip-to-hostname';
    }
}