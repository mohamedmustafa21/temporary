<?php

namespace App\Settings\Tools;

class RGBToHexSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-rgb-to-hex';
    }
}