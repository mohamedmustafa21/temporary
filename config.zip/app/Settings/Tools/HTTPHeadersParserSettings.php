<?php

namespace App\Settings\Tools;

class HTTPHeadersParserSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-http-headers-parser';
    }
}