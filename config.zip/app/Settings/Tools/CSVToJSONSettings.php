<?php

namespace App\Settings\Tools;

class CSVToJSONSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-csv-to-json';
    }
}