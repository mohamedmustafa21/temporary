<?php

namespace App\Settings\Tools;

class MD5GeneratorSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-md5-generator';
    }
}