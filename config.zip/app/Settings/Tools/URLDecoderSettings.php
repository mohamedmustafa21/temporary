<?php

namespace App\Settings\Tools;

class URLDecoderSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-url-decoder';
    }
}