<?php

namespace App\Settings\Tools;

class TextToBase64Settings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-text-to-base64';
    }
}