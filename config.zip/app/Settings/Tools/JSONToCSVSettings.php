<?php

namespace App\Settings\Tools;

class JSONToCSVSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-json-to-csv';
    }
}