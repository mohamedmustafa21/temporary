<?php

namespace App\Settings\Tools;

class HashGeneratorSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-hash-generator';
    }
}