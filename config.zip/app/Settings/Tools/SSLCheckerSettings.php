<?php

namespace App\Settings\Tools;

class SSLCheckerSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-ssl-checker';
    }
}