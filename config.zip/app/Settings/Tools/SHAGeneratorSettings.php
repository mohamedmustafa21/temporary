<?php

namespace App\Settings\Tools;

class SHAGeneratorSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-sha-generator';
    }
}