<?php

namespace App\Settings\Tools;

class HostnameToIPSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-hostname-to-ip';
    }
}