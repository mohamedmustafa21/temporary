<?php

namespace App\Settings\Tools;

class LoremIpsumGeneratorSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-lorem-ipsum-generator';
    }
}