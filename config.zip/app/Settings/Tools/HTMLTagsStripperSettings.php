<?php

namespace App\Settings\Tools;

class HTMLTagsStripperSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-html-tags-stripper';
    }
}