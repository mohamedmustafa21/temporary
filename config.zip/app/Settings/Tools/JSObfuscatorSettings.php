<?php

namespace App\Settings\Tools;

class JSObfuscatorSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-js-obfuscator';
    }
}