<?php

namespace App\Settings\Tools;

class HTMLFormatterSettings extends BaseToolSetting {
    public static function group(): string {
        return 'tool-html-formatter';
    }
}