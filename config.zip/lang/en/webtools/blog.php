<?php

return [
    'title' => 'Blog',
    'description' => 'News, Articles, Tips & Tricks from CyberTools',

    'no_posts' => 'No Posts to show.'
];