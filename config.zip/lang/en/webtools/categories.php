<?php

return [
    'utilities'   => 'Utilities',
    'converters'  => 'Converters',
    'content'     => 'Content',
    'security'    => 'Security',
    'calculators' => 'Calculators',
    'domains'     => 'Domains'
];