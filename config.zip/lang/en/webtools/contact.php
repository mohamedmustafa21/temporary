<?php

return [

    /*
    |--------------------------------------------------------------------------
    | WebTools Translation Files
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default messages used by
    | the webtools script.
    |
    */


    'heading'     => 'Contact Us',
    'description' => 'Get in touch with us'

];