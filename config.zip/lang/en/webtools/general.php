<?php

return [

    /*
    |--------------------------------------------------------------------------
    | WebTools Translation Files
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default messages used by
    | the webtools script.
    |
    */


    'related' => 'Related Tools',
    'copy'    => 'Copy',
    'download' => 'Download',
    'copied'  => 'Copied!'
];