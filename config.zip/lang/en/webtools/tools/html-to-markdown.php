<?php

return [
    'title'       => 'HTML To Markdown',
    'summary'     => 'Convert HTML Documents to Markdown.',
    'description' => 'HTML to Markdown is a converter that allows you to convert your HTML documents into Markdown Format. Markdown is a simplified format for creating documents. Paste in your HTML Code and click on the button to generate the Markdown.',

    'label' => 'Enter your HTML Here',
    'submit' => 'Convert to Markdown'
];