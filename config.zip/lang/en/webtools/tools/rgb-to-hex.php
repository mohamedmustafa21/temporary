<?php

return [
    'title'       => 'RGB To Hex',
    'summary'     => 'Convert RGB Colors to Hexcodes.',
    'description' => 'RGB To Hex is a useful tool that allows you to convert RGB Colors to Hex. Just type in your RGB Color and Click on the Button to convert to hex.',

    'red' => 'Red',
    'green' => 'Green',
    'blue' => 'Blue',
    'submit' => 'Convert',
    'result-placeholder' => 'Generated Color will be Here'
];