<?php

return [
    'title'       => 'YouTube Thumbnail Downloader',
    'summary'     => 'Download YouTube Thumbnails',
    'description' => 'YouTube Thumbnail Downloader is a useful tool that helps you download YouTube Thumbnails.',

    'label' => 'Enter the YouTube URL',
    'placeholder' => 'The YouTube Video URL to get the thumbnail from.',
    'submit' => 'Get Thumbnail'
];