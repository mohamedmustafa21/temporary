<?php

return [
    'title'       => 'URL Extractor',
    'summary'     => 'Extract URLs from Text',
    'description' => 'URL extractor is a useful tool that allows you to extract URLs from text.',

    'label' => 'Enter your Text',
    'submit' => 'Extract URLs'
];