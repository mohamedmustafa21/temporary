<?php

return [
    'title'       => 'Duplicate Lines Remover',
    'summary'     => 'Delete duplicate lines from text.',
    'description' => 'Duplicate Lines Remover is a useful tool that allows you to remoev duplicate lines from any piece of text. Make sure that each line is on a new line or separated via period. Click on the Button to remove the duplicate lines.',

    'label' => 'Enter your Text Here.',
    'submit' => 'Remove Duplicate Lines',
];