<?php

return [
    'title'       => 'SQL Beautifier',
    'summary'     => 'Format SQL Queries',
    'description' => 'SQL Beautifier is a useful tool that allows you to format your SQL Queries.',

    'label' => 'Enter your SQL Queries Here',
    'submit' => 'Beautify SQL'
];