<?php

return [
    'title'       => 'Bcrypt Generator',
    'summary'     => 'Generate Bcrypt Hashes',
    'description' => 'BCrypt Generator is a useful tool that allows you to generate BCrypt hashes.',

    'label' => 'Content to Hash',
    'placeholder' => 'Enter the Content you want to hash.',

    'submit' => 'Generate BCrypt',

];