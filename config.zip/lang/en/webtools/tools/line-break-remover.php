<?php

return [
    'title'       => 'Line Break Remover',
    'summary'     => 'Remove Line Breaks from Text',
    'description' => 'Line Break Remover is a useful tool that helps you remove line breaks from any piece of text.',

    'label' => 'Enter your Text',
    'submit' => 'Remove Line Breaks'
];