<?php

return [
    'title'       => 'Whats My IP',
    'summary'     => 'Find out your IP Address.',
    'description' => 'Whats My IP is a useful tool that helps you easily find your IP address.',

    'label' => 'IP Address: '
];