<?php

return [
    'title'       => 'User Agent Finder',
    'summary'     => 'Find out your user agent.',
    'description' => 'User Agent Finder is a useful tool that helps you easily find the user agent for your browser.',

    'label' => 'Your User Agent:',
    'placeholder' => 'Your user agent will appear here.'
];