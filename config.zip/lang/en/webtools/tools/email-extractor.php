<?php

return [
    'title'       => 'E-Mail Extractor',
    'summary'     => 'Extract E-Mails from Text',
    'description' => 'E-Mail extractor is a useful tool that allows you to extract email addresses from text.',

    'label' => 'Enter your Text',
    'submit' => 'Extract E-Mails'
];