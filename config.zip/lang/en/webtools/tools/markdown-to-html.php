<?php

return [
    'title'       => 'Markdown To HTML',
    'summary'     => 'Convert Markdown format to HTML.',
    'description' => 'Markdown to HTML is a converter that allows you to convert your markdown format text into HTML. Markdown is a simplified format for creating documents. Paste in your Markdown format and click on the button to generate the HTML.',

    'label' => 'Enter your Markdown Here',
    'submit' => 'Convert to HTML'
];