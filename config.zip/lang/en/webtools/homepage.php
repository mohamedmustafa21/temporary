<?php

return [

    /*
    |--------------------------------------------------------------------------
    | WebTools Translation Files
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default messages used by
    | the webtools script.
    |
    */

    'title'   => 'WebTools',
    'heading' => 'Useful Tools & Utilities to make life easier.',

    'search-placeholder' => 'Search any tool...'
];