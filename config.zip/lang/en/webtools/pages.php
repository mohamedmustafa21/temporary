<?php

return [
    /*
    |--------------------------------------------------------------------------
    | WebTools Translation Files
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default messages used by
    | the webtools script.
    |
    */

    'homepage'  => 'Useful Tools & Utilities',
    'contact'   => 'Get in Touch with Us',

    'home-link'    => 'Home',
    'contact-link' => 'Contact Us',
    'blog-link'    => 'Blog'
];