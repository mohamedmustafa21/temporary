<?php

return [
    'submit' => 'Submit',
    
    'name' => 'Your Name',
    'name-placeholder' => 'Your Name Here',

    'email' => 'Your E-Mail',
    'email-placeholder' => 'Your E-Mail Here',
    
    'message' => 'Message',
    'message-placeholder' => 'Your message here...',

    'recaptcha-required' => 'ReCaptcha validation is required.',
    'contact-error'      => 'There was an error sending your contact message. Please try again later.',
    'contact-sent'       => 'Your message was sent successfully.'
];