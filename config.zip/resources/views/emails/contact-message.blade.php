<div>
    <div>
        Name: {{ $name != '' ? $name : 'Unknown' }}
    </div>
    <div>
        Email: {{ $email }}
    </div>
    <hr>
    <hr>
    <div>
        {{ $messages }}
    </div>
</div>