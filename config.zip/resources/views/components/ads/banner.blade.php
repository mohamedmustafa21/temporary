<div class="my-5 text-center">
    {!! $code !!}
</div>