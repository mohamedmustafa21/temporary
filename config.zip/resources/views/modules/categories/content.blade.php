<div class="content-title-icon">
    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="27" viewBox="0 0 30 27">
        <path id="bxs-book-content" d="M30,4.5H6a3,3,0,0,0-3,3v21a3,3,0,0,0,3,3H30a3,3,0,0,0,3-3V7.5A3,3,0,0,0,30,4.5Zm-1.5,6v3H21v-3Zm-7.5,6h7.5v3H21ZM6,28.5V7.5H16.5v21Z" transform="translate(-3 -4.5)" fill="#fff"/>
    </svg>						  
</div>

<h3>{{ trans('webtools/categories.content') }}</h3>